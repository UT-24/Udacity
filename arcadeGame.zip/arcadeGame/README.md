Arcade Game
===============================


### Running the Game

To run the game, simply open the **index.html** file in the folder in your chrome browser.

### Playing the game
In this game you have a Player and Enemies (Bugs). The goal of the player is to reach the water, without colliding into any one of the enemies. The player can move left, right, up and down. The enemies move in varying speeds on the paved block portion of the scene. Once a the player collides with an enemy, the score gets decremented by 1 and the player moves back to the start square. Once the player reaches the water the score gets incremented by 1 and again, the player is moved to the start square.

To play the game, move the player using:

* Left arrow key to move the player to the left
* Right arrow key to move the player to the right
* Up arrow key to move the player up and 
* Down  arrow key to move the player down

